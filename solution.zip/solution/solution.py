import random #-----------> import a random number generator

f_g = [] #----------> first group, it looks like ['x','o','x']
s_g = [] #----------> second group, it looks like ['x','o','x']
t_g = [] #----------> third group, it looks like ['x','o','x']

len_fg = len(f_g) #----------> to get the length of the  first group
len_sg = len(s_g) #----------> to get the length of the  second group
len_tg = len(t_g) #----------> to get the length of the  third group

board_row = len_fg + len_sg + len_tg #----------> to see if the 3x3 board is already filled  with letters

x_win = "" #----------> to know if the x win
o_win = "" #----------> to know if the o win
x_win_list = 0 #----------> to hold the number of x wins
o_win_list = 0 #----------> to hold the number of o wins

for i in range(10): #----------> to run the game for 10 times
    while board_row < 9: #----------> if the board is not yet filled with letters it keep on picking numbers and it will be use to get a letter from the letters collection
        try: # this code handles the error effeciently, if error happens the program will not crashed.
            len_fg = len(f_g) #----------> it checks how many letters in the first group
            len_sg = len(s_g) #----------> it checks how many letters in the second group
            len_tg = len(t_g) #----------> it checks how many letters in the third group

            board_row = len_fg + len_sg + len_tg #----------> to see if the board is already filled  with letters

            letters = [] # this is the variable or basket to hold the collection of letters, it only accept letter "x" or "o"
                         # the content look like this                                           |
                                            #                                                   |
                                            #                                                   |
                                            #                                                   v
                                            #                                                   v
                # ['X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O',
                #  'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', '
                #  X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', '
                #  X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O',
                #   'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 
                #   'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 
                #   'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 
                #   'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O',
                #    'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 
                #    'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 
                #    'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 
                #    'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 
                #    'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 
                #    'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 
                #    'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 
                #    'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 
                #    'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 
                #    'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 
                #    'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', '
                #    X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O']

            for i in range(300):  # this is the letters generator, the output looks like below this      |
                                  #                                                                      |
                                  #                                                                      |
                                  #                                                                      v
                                  #                                                                      v
                # ['X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O',
                #  'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', '
                #  X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', '
                #  X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O',
                #   'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 
                #   'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 
                #   'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 
                #   'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O',
                #    'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 
                #    'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 
                #    'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 
                #    'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 
                #    'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 
                #    'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 
                #    'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 
                #    'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 
                #    'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 
                #    'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 
                #    'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', '
                #    X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O', 'X', 'O']
                for i in 'XO':
                    letters.append(i) # add x and o to letters collection


            total_num = len(letters) # to get the length of the letters that was generated
            picked_number = random.randint(0,total_num) # it picked a  number, the limit of the choices is based to the length of the letters collection "letters = []"
            print('picked number'+str(picked_number)) # it simply display the picked number, to see that the random number is working and its not picking the same number
            picked_letter = letters[picked_number]  # i picked a  letter
            print('picked letter '+picked_letter) #i simply display the picked letter, to see that the picked letter is not the same from previous picked.

            if picked_number < 100: # if the picked number is less than 100, if just put the picked letter to the first group
                if len_fg == 3: # if the first group is already filled with letters it will not accept adding a letters
                    pass  # simply to do nothing to avoid error
                else:
                    f_g.append(picked_letter) # insert the picked letter to the first group
            elif picked_number > 100: # if the picked number is greater than 100, if just put the picked letter to the second group
                if len_sg == 3: # if the second group is already filled with letters it will not accept adding a letters
                    pass  # simply to do nothing to avoid error
                else:
                    s_g.append(picked_letter)  # insert the picked letter to the second group
            else: # if the picked number is not less than 100 and not greater than 200, if simply added the picked letter to third group
                if len_tg == 3: # if the third group is already filled with letters it will not accept adding a letters
                    pass  # simply to do nothing to avoid error
                else:
                    t_g.append(picked_letter)  # insert the picked letter to the third group

            fg_1 = f_g[0] #this block of codes simply to see who wins in a first group
            fg_2 = f_g[1]
            fg_3 = f_g[2]
            if fg_1 == fg_2:
                if fg_2 == fg_3:
                    if fg_3 == "X":
                        x_win = "yes"
                    else:
                        o_win = "yes"
            else:
                pass  # simply to do nothing to avoid error


            tg_1 = t_g[0] #this block of codes simply to see who wins in a second group
            tg_2 = t_g[1]
            tg_3 = t_g[2]
            if tg_1 == tg_2:
                if tg_2 == tg_3:
                    if tg_3 == "X":
                        x_win = "yes"
                    else:
                        o_win = "yes"
            else:
                pass  # simply to do nothing to avoid error


            fg_1 = f_g[0] #this block of codes simply to see who wins in a first group
            fg_2 = f_g[1]
            fg_3 = f_g[2]
            if fg_1 == fg_2:
                if fg_2 == fg_3:
                    if fg_3 == "X":
                        x_win = "yes"
                    else:
                        o_win = "yes"
            else:
                pass  # simply to do nothing to avoid error
                
        except:
            pass  # simply to do nothing to avoid error

    print(f_g) #display the first group content
    print(s_g) #display the second group content
    print(t_g) #display the third group content
    print('-----------------------------------'+str(i)) #to display the number of rounds the game played
    if x_win == "yes":  # confirm that the x win
        x_win_list += 1  # increase the x wins
        print('--------------------X win------')  # simply display that x wins
    elif o_win == "yes":  # confirm that the o win
        print('--------------------O win------')  # simply display that o wins
        o_win_list += 1  # increase the o wins
    else:
        pass  # simply to do nothing to avoid error
    print('')  # to display a line break for readability


print("X wins "+str(x_win_list)+" out of 10")  # to display how many times x has won.
print("O wins "+str(o_win_list)+" out of 10")  # to display how many times o has won.




val = input("Enter any key and press enter to exit: ") 


